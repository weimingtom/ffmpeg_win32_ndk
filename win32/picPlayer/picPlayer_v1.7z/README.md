videoPlayer
===========

a very simple  video player with SDL & ffmpeg
