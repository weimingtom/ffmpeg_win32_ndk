//#include "SDL_config.h"
#include "SDL_stdinc.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "SDL_timer.h"
void SDL_Delay(Uint32 ms)
{
	Sleep(ms);
}
