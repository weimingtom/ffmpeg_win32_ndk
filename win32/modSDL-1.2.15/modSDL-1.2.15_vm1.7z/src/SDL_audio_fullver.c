//#include "SDL_config.h"

#include "SDL.h"
#include "SDL_thread.h"
#include "SDL_audio.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>


#define DEBUG_CONVERT 1
#define DEBUG_AUDIO 1
#define DEBUG_BUILD 1

#define SDL_AllocAudioMem	SDL_malloc
#define SDL_FreeAudioMem	SDL_free

//search 'needed'
//SDL_ConvertMono
//SDL_BuildAudioCVT -> SDL_OpenAudio
//SDL_ConvertAudio -> SDL_RunAudio

typedef struct SDL_AudioDevice SDL_AudioDevice;

#define _THIS	SDL_AudioDevice *_this
#ifndef _STATUS
#define _STATUS	SDL_status *status
#endif
struct SDL_AudioDevice {
	const char *name;
	const char *desc;
	int  (*OpenAudio)(_THIS, SDL_AudioSpec *spec);
	void (*ThreadInit)(_THIS);
	void (*WaitAudio)(_THIS);
	void (*PlayAudio)(_THIS);
	Uint8 *(*GetAudioBuf)(_THIS);
	void (*WaitDone)(_THIS);
	void (*CloseAudio)(_THIS);
	void (*LockAudio)(_THIS);
	void (*UnlockAudio)(_THIS);
	void (*SetCaption)(_THIS, const char *caption);
	SDL_AudioSpec spec;
	SDL_AudioCVT convert;
	int enabled;
	int paused;
	int opened;
	Uint8 *fake_stream;
	SDL_mutex *mixer_lock;
	SDL_Thread *thread;
	Uint32 threadid;
	struct SDL_PrivateAudioData *hidden;
	void (*free)(_THIS);
};
#undef _THIS

typedef struct AudioBootStrap {
	const char *name;
	const char *desc;
	int (*available)(void);
	SDL_AudioDevice *(*create)(int devindex);
} AudioBootStrap;

extern AudioBootStrap WAVEOUT_bootstrap;

extern SDL_AudioDevice *current_audio;




#define _THIS	SDL_AudioDevice *this

#define NUM_BUFFERS 2

struct SDL_PrivateAudioData {
	HWAVEOUT sound;
	HANDLE audio_sem;
	Uint8 *mixbuf;
	WAVEHDR wavebuf[NUM_BUFFERS];
	int next_buffer;
};

#define sound			(this->hidden->sound)
#define audio_sem 		(this->hidden->audio_sem)
#define mixbuf			(this->hidden->mixbuf)
#define wavebuf			(this->hidden->wavebuf)
#define next_buffer		(this->hidden->next_buffer)



extern Uint16 SDL_FirstAudioFormat(Uint16 format);
extern Uint16 SDL_NextAudioFormat(void);

extern void SDL_CalculateAudioSpec(SDL_AudioSpec *spec);

extern int SDLCALL SDL_RunAudio(void *audiop);

static AudioBootStrap *bootstrap[] = {
	&WAVEOUT_bootstrap,
	NULL
};
SDL_AudioDevice *current_audio = NULL;

int SDL_AudioInit(const char *driver_name);
void SDL_AudioQuit(void);



















static int DIB_OpenAudio(_THIS, SDL_AudioSpec *spec);
static void DIB_ThreadInit(_THIS);
static void DIB_WaitAudio(_THIS);
static Uint8 *DIB_GetAudioBuf(_THIS);
static void DIB_PlayAudio(_THIS);
static void DIB_WaitDone(_THIS);
static void DIB_CloseAudio(_THIS);

static int Audio_Available(void)
{
	return(1);
}

static void Audio_DeleteDevice(SDL_AudioDevice *device)
{
	SDL_free(device->hidden);
	SDL_free(device);
}

static SDL_AudioDevice *Audio_CreateDevice(int devindex)
{
	SDL_AudioDevice *this;
	this = (SDL_AudioDevice *)SDL_malloc(sizeof(SDL_AudioDevice));
	if ( this ) {
		SDL_memset(this, 0, (sizeof *this));
		this->hidden = (struct SDL_PrivateAudioData *)
				SDL_malloc((sizeof *this->hidden));
	}
	if ( (this == NULL) || (this->hidden == NULL) ) {
		SDL_OutOfMemory();
		if ( this ) {
			SDL_free(this);
		}
		return(0);
	}
	SDL_memset(this->hidden, 0, (sizeof *this->hidden));
	this->OpenAudio = DIB_OpenAudio;
	this->ThreadInit = DIB_ThreadInit;
	this->WaitAudio = DIB_WaitAudio;
	this->PlayAudio = DIB_PlayAudio;
	this->GetAudioBuf = DIB_GetAudioBuf;
	this->WaitDone = DIB_WaitDone;
	this->CloseAudio = DIB_CloseAudio;
	this->free = Audio_DeleteDevice;
	return this;
}

AudioBootStrap WAVEOUT_bootstrap = {
	"waveout", "Win95/98/NT/2000 WaveOut",
	Audio_Available, Audio_CreateDevice
};

static void CALLBACK FillSound(HWAVEOUT hwo, UINT uMsg, DWORD_PTR dwInstance,
						DWORD dwParam1, DWORD dwParam2)
{
	SDL_AudioDevice *this = (SDL_AudioDevice *)dwInstance;
	if ( uMsg != WOM_DONE )
		return;
	ReleaseSemaphore(audio_sem, 1, NULL);
}

static void SetMMerror(char *function, MMRESULT code)
{
	size_t len;
	char errbuf[MAXERRORLENGTH];
	SDL_snprintf(errbuf, SDL_arraysize(errbuf), "%s: ", function);
	len = SDL_strlen(errbuf);
	waveOutGetErrorText(code, errbuf+len, (UINT)(MAXERRORLENGTH-len));
	SDL_SetError("%s",errbuf);
}

static void DIB_ThreadInit(_THIS)
{
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
}

void DIB_WaitAudio(_THIS)
{
	WaitForSingleObject(audio_sem, INFINITE);
}

Uint8 *DIB_GetAudioBuf(_THIS)
{
    Uint8 *retval;
	retval = (Uint8 *)(wavebuf[next_buffer].lpData);
	return retval;
}

void DIB_PlayAudio(_THIS)
{
	waveOutWrite(sound, &wavebuf[next_buffer], sizeof(wavebuf[0]));
	next_buffer = (next_buffer+1)%NUM_BUFFERS;
}

void DIB_WaitDone(_THIS)
{
	int i, left;
	do {
		left = NUM_BUFFERS;
		for ( i=0; i<NUM_BUFFERS; ++i ) {
			if ( wavebuf[i].dwFlags & WHDR_DONE ) {
				--left;
			}
		}
		if ( left > 0 ) {
			SDL_Delay(100);
		}
	} while ( left > 0 );
}

void DIB_CloseAudio(_THIS)
{
	int i;
	if ( audio_sem ) {
		CloseHandle(audio_sem);
	}
	if ( sound ) {
		waveOutClose(sound);
	}
	for ( i=0; i<NUM_BUFFERS; ++i ) {
		if ( wavebuf[i].dwUser != 0xFFFF ) {
			waveOutUnprepareHeader(sound, &wavebuf[i],
						sizeof(wavebuf[i]));
			wavebuf[i].dwUser = 0xFFFF;
		}
	}
	if ( mixbuf != NULL ) {
		SDL_free(mixbuf);
		mixbuf = NULL;
	}
}

int DIB_OpenAudio(_THIS, SDL_AudioSpec *spec)
{
	MMRESULT result;
	int i;
	WAVEFORMATEX waveformat;
	sound = NULL;
	audio_sem = NULL;
	for ( i = 0; i < NUM_BUFFERS; ++i )
		wavebuf[i].dwUser = 0xFFFF;
	mixbuf = NULL;
	SDL_memset(&waveformat, 0, sizeof(waveformat));
	waveformat.wFormatTag = WAVE_FORMAT_PCM;
	switch ( spec->format & 0xFF ) {
	case 8:
		spec->format = AUDIO_U8;
		waveformat.wBitsPerSample = 8;
		break;
		
	case 16:
		spec->format = AUDIO_S16;
		waveformat.wBitsPerSample = 16;
		break;
		
	default:
		SDL_SetError("Unsupported audio format");
		return(-1);
	}
	waveformat.nChannels = spec->channels;
	waveformat.nSamplesPerSec = spec->freq;
	waveformat.nBlockAlign =
		waveformat.nChannels * (waveformat.wBitsPerSample/8);
	waveformat.nAvgBytesPerSec = 
		waveformat.nSamplesPerSec * waveformat.nBlockAlign;
	if ( spec->samples < (spec->freq/4) )
		spec->samples = ((spec->freq/4)+3)&~3;
	SDL_CalculateAudioSpec(spec);
	result = waveOutOpen(&sound, WAVE_MAPPER, &waveformat,
			(DWORD_PTR)FillSound, (DWORD_PTR)this, CALLBACK_FUNCTION);
	if ( result != MMSYSERR_NOERROR ) {
		SetMMerror("waveOutOpen()", result);
		return(-1);
	}
#ifdef SOUND_DEBUG
	{
		WAVEOUTCAPS caps;
		result = waveOutGetDevCaps((UINT)sound, &caps, sizeof(caps));
		if ( result != MMSYSERR_NOERROR ) {
			SetMMerror("waveOutGetDevCaps()", result);
			return(-1);
		}
		printf("Audio device: %s\n", caps.szPname);
	}
#endif
	audio_sem = CreateSemaphore(NULL, NUM_BUFFERS-1, NUM_BUFFERS, NULL);
	if ( audio_sem == NULL ) {
		SDL_SetError("Couldn't create semaphore");
		return(-1);
	}
	mixbuf = (Uint8 *)SDL_malloc(NUM_BUFFERS*spec->size);
	if ( mixbuf == NULL ) {
		SDL_SetError("Out of memory");
		return(-1);
	}
	for ( i = 0; i < NUM_BUFFERS; ++i ) {
		SDL_memset(&wavebuf[i], 0, sizeof(wavebuf[i]));
		wavebuf[i].lpData = (LPSTR) &mixbuf[i*spec->size];
		wavebuf[i].dwBufferLength = spec->size;
		wavebuf[i].dwFlags = WHDR_DONE;
		result = waveOutPrepareHeader(sound, &wavebuf[i],
							sizeof(wavebuf[i]));
		if ( result != MMSYSERR_NOERROR ) {
			SetMMerror("waveOutPrepareHeader()", result);
			return(-1);
		}
	}
	next_buffer = 0;
	return(0);
}























int SDLCALL SDL_RunAudio(void *audiop)
{
	SDL_AudioDevice *audio = (SDL_AudioDevice *)audiop;
	Uint8 *stream;
	int    stream_len;
	void  *udata;
	void (SDLCALL *fill)(void *userdata,Uint8 *stream, int len);
	int    silence;
	if ( audio->ThreadInit ) {
		audio->ThreadInit(audio);
	}
	audio->threadid = SDL_ThreadID();
	fill  = audio->spec.callback;
	udata = audio->spec.userdata;
	if ( audio->convert.needed ) {
		if ( audio->convert.src_format == AUDIO_U8 ) {
			silence = 0x80;
		} else {
			silence = 0;
		}
		stream_len = audio->convert.len;
	} else {
		silence = audio->spec.silence;
		stream_len = audio->spec.size;
	}
	while ( audio->enabled ) {
		if ( audio->convert.needed ) {
			if ( audio->convert.buf ) {
				stream = audio->convert.buf;
			} else {
				continue;
			}
		} else {
			stream = audio->GetAudioBuf(audio);
			if ( stream == NULL ) {
				stream = audio->fake_stream;
			}
		}
		SDL_memset(stream, silence, stream_len);
		if ( ! audio->paused ) {
			SDL_mutexP(audio->mixer_lock);
			(*fill)(udata, stream, stream_len);
			SDL_mutexV(audio->mixer_lock);
		}
		if ( audio->convert.needed ) {
			SDL_ConvertAudio(&audio->convert);
			stream = audio->GetAudioBuf(audio);
			if ( stream == NULL ) {
				stream = audio->fake_stream;
			}
			SDL_memcpy(stream, audio->convert.buf,
			               audio->convert.len_cvt);
		}
		if ( stream != audio->fake_stream ) {
			audio->PlayAudio(audio);
		}
		if ( stream == audio->fake_stream ) {
			SDL_Delay((audio->spec.samples*1000)/audio->spec.freq);
		} else {
			audio->WaitAudio(audio);
		}
	}
	if ( audio->WaitDone ) {
#ifdef DEBUG_BUILD
        printf("[SDL_RunAudio] : Task wait done..... (TID%d)\n", SDL_ThreadID());
#endif
		audio->WaitDone(audio);
	}
#ifdef DEBUG_BUILD
        printf("[SDL_RunAudio] : Task exiting. (TID%d)\n", SDL_ThreadID());
#endif
	return(0);
}

static void SDL_LockAudio_Default(SDL_AudioDevice *audio)
{
	if ( audio->thread && (SDL_ThreadID() == audio->threadid) ) {
		return;
	}
	SDL_mutexP(audio->mixer_lock);
}

static void SDL_UnlockAudio_Default(SDL_AudioDevice *audio)
{
	if ( audio->thread && (SDL_ThreadID() == audio->threadid) ) {
		return;
	}
	SDL_mutexV(audio->mixer_lock);
}

static Uint16 SDL_ParseAudioFormat(const char *string)
{
	Uint16 format = 0;
	switch (*string) {
	    case 'U':
		++string;
		format |= 0x0000;
		break;
	    case 'S':
		++string;
		format |= 0x8000;
		break;
	    default:
		return 0;
	}
	switch (SDL_atoi(string)) {
	    case 8:
		string += 1;
		format |= 8;
		break;
	    case 16:
		string += 2;
		format |= 16;
		if ( SDL_strcmp(string, "LSB") == 0
#if SDL_BYTEORDER == SDL_LIL_ENDIAN
		     || SDL_strcmp(string, "SYS") == 0
#endif
		    ) {
			format |= 0x0000;
		}
		if ( SDL_strcmp(string, "MSB") == 0
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
		     || SDL_strcmp(string, "SYS") == 0
#endif
		    ) {
			format |= 0x1000;
		}
		break;
	    default:
		return 0;
	}
	return format;
}

int SDL_AudioInit(const char *driver_name)
{
	SDL_AudioDevice *audio;
	int i = 0, idx;
	if ( current_audio != NULL ) {
		SDL_AudioQuit();
	}
	audio = NULL;
	idx = 0;
	if ( audio == NULL ) {
		if ( driver_name != NULL ) {
			for ( i=0; bootstrap[i]; ++i ) {
				if (SDL_strcasecmp(bootstrap[i]->name, driver_name) == 0) {
					if ( bootstrap[i]->available() ) {
						audio=bootstrap[i]->create(idx);
						break;
					}
				}
			}
		} else {
			for ( i=0; bootstrap[i]; ++i ) {
				if ( bootstrap[i]->available() ) {
					audio = bootstrap[i]->create(idx);
					if ( audio != NULL ) {
						break;
					}
				}
			}
		}
		if ( audio == NULL ) {
			SDL_SetError("No available audio device");
		}
	}
	current_audio = audio;
	if ( current_audio ) {
		current_audio->name = bootstrap[i]->name;
		if ( !current_audio->LockAudio && !current_audio->UnlockAudio ) {
			current_audio->LockAudio = SDL_LockAudio_Default;
			current_audio->UnlockAudio = SDL_UnlockAudio_Default;
		}
	}
	return(0);
}

char *SDL_AudioDriverName(char *namebuf, int maxlen)
{
	if ( current_audio != NULL ) {
		SDL_strlcpy(namebuf, current_audio->name, maxlen);
		return(namebuf);
	}
	return(NULL);
}

int SDL_OpenAudio(SDL_AudioSpec *desired, SDL_AudioSpec *obtained)
{
	SDL_AudioDevice *audio;
	const char *env;
	if ( ! current_audio ) {
		if ( (SDL_AudioInit(NULL) < 0) ||
		     (current_audio == NULL) ) {
			return(-1);
		}
	}
	audio = current_audio;
	if (audio->opened) {
		SDL_SetError("Audio device is already opened");
		return(-1);
	}
	if ( desired->freq == 0 ) {
		desired->freq = 22050;
	}
	if ( desired->format == 0 ) {
		desired->format = AUDIO_S16;
	}
	if ( desired->channels == 0 ) {
		desired->channels = 2;
	}
	switch ( desired->channels ) {
	case 1:
	case 2:
	case 4:
	case 6:
		break;
		
	default:
		SDL_SetError("1 (mono) and 2 (stereo) channels supported");
		return(-1);
	}
	if ( desired->samples == 0 ) {
		int samples = (desired->freq / 1000) * 46;
		int power2 = 1;
		while ( power2 < samples ) {
			power2 *= 2;
		}
		desired->samples = power2;
	}
	if ( desired->callback == NULL ) {
		SDL_SetError("SDL_OpenAudio() passed a NULL callback");
		return(-1);
	}

#if SDL_THREADS_DISABLED

#else
	audio->mixer_lock = SDL_CreateMutex();
	if ( audio->mixer_lock == NULL ) {
		SDL_SetError("Couldn't create mixer lock");
		SDL_CloseAudio();
		return(-1);
	}
#endif
	SDL_CalculateAudioSpec(desired);
	SDL_memcpy(&audio->spec, desired, sizeof(audio->spec));
	audio->convert.needed = 0;
	audio->enabled = 1;
	audio->paused  = 1;
	audio->opened = audio->OpenAudio(audio, &audio->spec)+1;
	if ( ! audio->opened ) {
		SDL_CloseAudio();
		return(-1);
	}
	if ( audio->spec.samples != desired->samples ) {
		desired->samples = audio->spec.samples;
		SDL_CalculateAudioSpec(desired);
	}
	audio->fake_stream = SDL_AllocAudioMem(audio->spec.size);
	if ( audio->fake_stream == NULL ) {
		SDL_CloseAudio();
		SDL_OutOfMemory();
		return(-1);
	}
	if ( obtained != NULL ) {
		SDL_memcpy(obtained, &audio->spec, sizeof(audio->spec));
	} else if ( desired->freq != audio->spec.freq ||
                    desired->format != audio->spec.format ||
	            desired->channels != audio->spec.channels ) {
		if ( SDL_BuildAudioCVT(&audio->convert,
			desired->format, desired->channels,
					desired->freq,
			audio->spec.format, audio->spec.channels,
					audio->spec.freq) < 0 ) {
			SDL_CloseAudio();
			return(-1);
		}
		if ( audio->convert.needed ) {
			audio->convert.len = (int) ( ((double) audio->spec.size) /
                                          audio->convert.len_ratio );
			audio->convert.buf =(Uint8 *)SDL_AllocAudioMem(
			   audio->convert.len*audio->convert.len_mult);
			if ( audio->convert.buf == NULL ) {
				SDL_CloseAudio();
				SDL_OutOfMemory();
				return(-1);
			}
		}
	}
	switch (audio->opened) {
	case 1:
		audio->thread = SDL_CreateThread(SDL_RunAudio, audio);
		if ( audio->thread == NULL ) {
			SDL_CloseAudio();
			SDL_SetError("Couldn't create audio thread");
			return(-1);
		}
		break;
		
	default:
		break;
	}
	return(0);
}

SDL_audiostatus SDL_GetAudioStatus(void)
{
	SDL_AudioDevice *audio = current_audio;
	SDL_audiostatus status;
	status = SDL_AUDIO_STOPPED;
	if ( audio && audio->enabled ) {
		if ( audio->paused ) {
			status = SDL_AUDIO_PAUSED;
		} else {
			status = SDL_AUDIO_PLAYING;
		}
	}
	return(status);
}

void SDL_PauseAudio (int pause_on)
{
	SDL_AudioDevice *audio = current_audio;
	if ( audio ) {
		audio->paused = pause_on;
	}
}

void SDL_LockAudio (void)
{
	SDL_AudioDevice *audio = current_audio;
	if ( audio && audio->LockAudio ) {
		audio->LockAudio(audio);
	}
}

void SDL_UnlockAudio (void)
{
	SDL_AudioDevice *audio = current_audio;
	if ( audio && audio->UnlockAudio ) {
		audio->UnlockAudio(audio);
	}
}

void SDL_CloseAudio (void)
{
	SDL_AudioQuit();
}

void SDL_AudioQuit(void)
{
	SDL_AudioDevice *audio = current_audio;
	if ( audio ) {
		audio->enabled = 0;
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 1...\n");
#endif
		if ( audio->thread != NULL ) {
			SDL_WaitThread(audio->thread, NULL);
		}
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 2...\n");
#endif
		if ( audio->mixer_lock != NULL ) {
			SDL_DestroyMutex(audio->mixer_lock);
		}
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 3...\n");
#endif
		if ( audio->fake_stream != NULL ) {
			SDL_FreeAudioMem(audio->fake_stream);
		}
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 4...\n");
#endif
		if ( audio->convert.needed ) {
			SDL_FreeAudioMem(audio->convert.buf);
		}
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 5...\n");
#endif
		if ( audio->opened ) {
			audio->CloseAudio(audio);
			audio->opened = 0;
		}
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 6...\n");
#endif
		audio->free(audio);
		current_audio = NULL;
#if DEBUG_AUDIO
	printf("SDL_AudioQuit() 7...\n");
#endif
	}
}

#define NUM_FORMATS	6
static int format_idx;
static int format_idx_sub;
static Uint16 format_list[NUM_FORMATS][NUM_FORMATS] = {
 { AUDIO_U8, AUDIO_S8, AUDIO_S16LSB, AUDIO_S16MSB, AUDIO_U16LSB, AUDIO_U16MSB },
 { AUDIO_S8, AUDIO_U8, AUDIO_S16LSB, AUDIO_S16MSB, AUDIO_U16LSB, AUDIO_U16MSB },
 { AUDIO_S16LSB, AUDIO_S16MSB, AUDIO_U16LSB, AUDIO_U16MSB, AUDIO_U8, AUDIO_S8 },
 { AUDIO_S16MSB, AUDIO_S16LSB, AUDIO_U16MSB, AUDIO_U16LSB, AUDIO_U8, AUDIO_S8 },
 { AUDIO_U16LSB, AUDIO_U16MSB, AUDIO_S16LSB, AUDIO_S16MSB, AUDIO_U8, AUDIO_S8 },
 { AUDIO_U16MSB, AUDIO_U16LSB, AUDIO_S16MSB, AUDIO_S16LSB, AUDIO_U8, AUDIO_S8 },
};

Uint16 SDL_FirstAudioFormat(Uint16 format)
{
	for ( format_idx=0; format_idx < NUM_FORMATS; ++format_idx ) {
		if ( format_list[format_idx][0] == format ) {
			break;
		}
	}
	format_idx_sub = 0;
	return(SDL_NextAudioFormat());
}

Uint16 SDL_NextAudioFormat(void)
{
	if ( (format_idx == NUM_FORMATS) || (format_idx_sub == NUM_FORMATS) ) {
		return(0);
	}
	return(format_list[format_idx][format_idx_sub++]);
}

void SDL_CalculateAudioSpec(SDL_AudioSpec *spec)
{
	switch (spec->format) {
	case AUDIO_U8:
		spec->silence = 0x80;
		break;
		
	default:
		spec->silence = 0x00;
		break;
	}
	spec->size = (spec->format&0xFF)/8;
	spec->size *= spec->channels;
	spec->size *= spec->samples;
}

void SDL_Audio_SetCaption(const char *caption)
{
	if ((current_audio) && (current_audio->SetCaption)) {
		current_audio->SetCaption(current_audio, caption);
	}
}

























void SDLCALL SDL_ConvertMono(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Sint32 sample;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting to mono\n");
#endif
	switch (format&0x8018) {

		case AUDIO_U8: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			for ( i=cvt->len_cvt/2; i; --i ) {
				sample = src[0] + src[1];
				*dst = (Uint8)(sample / 2);
				src += 2;
				dst += 1;
			}
		}
		break;

		case AUDIO_S8: {
			Sint8 *src, *dst;

			src = (Sint8 *)cvt->buf;
			dst = (Sint8 *)cvt->buf;
			for ( i=cvt->len_cvt/2; i; --i ) {
				sample = src[0] + src[1];
				*dst = (Sint8)(sample / 2);
				src += 2;
				dst += 1;
			}
		}
		break;

		case AUDIO_U16: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/4; i; --i ) {
					sample = (Uint16)((src[0]<<8)|src[1])+
					         (Uint16)((src[2]<<8)|src[3]);
					sample /= 2;
					dst[1] = (sample&0xFF);
					sample >>= 8;
					dst[0] = (sample&0xFF);
					src += 4;
					dst += 2;
				}
			} else {
				for ( i=cvt->len_cvt/4; i; --i ) {
					sample = (Uint16)((src[1]<<8)|src[0])+
					         (Uint16)((src[3]<<8)|src[2]);
					sample /= 2;
					dst[0] = (sample&0xFF);
					sample >>= 8;
					dst[1] = (sample&0xFF);
					src += 4;
					dst += 2;
				}
			}
		}
		break;

		case AUDIO_S16: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/4; i; --i ) {
					sample = (Sint16)((src[0]<<8)|src[1])+
					         (Sint16)((src[2]<<8)|src[3]);
					sample /= 2;
					dst[1] = (sample&0xFF);
					sample >>= 8;
					dst[0] = (sample&0xFF);
					src += 4;
					dst += 2;
				}
			} else {
				for ( i=cvt->len_cvt/4; i; --i ) {
					sample = (Sint16)((src[1]<<8)|src[0])+
					         (Sint16)((src[3]<<8)|src[2]);
					sample /= 2;
					dst[0] = (sample&0xFF);
					sample >>= 8;
					dst[1] = (sample&0xFF);
					src += 4;
					dst += 2;
				}
			}
		}
		break;
	}
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

/* Discard top 4 channels */
void SDLCALL SDL_ConvertStrip(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Sint32 lsample, rsample;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting down to stereo\n");
#endif
	switch (format&0x8018) {

		case AUDIO_U8: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			for ( i=cvt->len_cvt/6; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				src += 6;
				dst += 2;
			}
		}
		break;

		case AUDIO_S8: {
			Sint8 *src, *dst;

			src = (Sint8 *)cvt->buf;
			dst = (Sint8 *)cvt->buf;
			for ( i=cvt->len_cvt/6; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				src += 6;
				dst += 2;
			}
		}
		break;

		case AUDIO_U16: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/12; i; --i ) {
					lsample = (Uint16)((src[0]<<8)|src[1]);
					rsample = (Uint16)((src[2]<<8)|src[3]);
						dst[1] = (lsample&0xFF);
						lsample >>= 8;
						dst[0] = (lsample&0xFF);
						dst[3] = (rsample&0xFF);
						rsample >>= 8;
						dst[2] = (rsample&0xFF);
					src += 12;
					dst += 4;
				}
			} else {
				for ( i=cvt->len_cvt/12; i; --i ) {
					lsample = (Uint16)((src[1]<<8)|src[0]);
					rsample = (Uint16)((src[3]<<8)|src[2]);
						dst[0] = (lsample&0xFF);
						lsample >>= 8;
						dst[1] = (lsample&0xFF);
						dst[2] = (rsample&0xFF);
						rsample >>= 8;
						dst[3] = (rsample&0xFF);
					src += 12;
					dst += 4;
				}
			}
		}
		break;

		case AUDIO_S16: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/12; i; --i ) {
					lsample = (Sint16)((src[0]<<8)|src[1]);
					rsample = (Sint16)((src[2]<<8)|src[3]);
						dst[1] = (lsample&0xFF);
						lsample >>= 8;
						dst[0] = (lsample&0xFF);
						dst[3] = (rsample&0xFF);
						rsample >>= 8;
						dst[2] = (rsample&0xFF);
					src += 12;
					dst += 4;
				}
			} else {
				for ( i=cvt->len_cvt/12; i; --i ) {
					lsample = (Sint16)((src[1]<<8)|src[0]);
					rsample = (Sint16)((src[3]<<8)|src[2]);
						dst[0] = (lsample&0xFF);
						lsample >>= 8;
						dst[1] = (lsample&0xFF);
						dst[2] = (rsample&0xFF);
						rsample >>= 8;
						dst[3] = (rsample&0xFF);
					src += 12;
					dst += 4;
				}
			}
		}
		break;
	}
	cvt->len_cvt /= 3;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}


/* Discard top 2 channels of 6 */
void SDLCALL SDL_ConvertStrip_2(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Sint32 lsample, rsample;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting 6 down to quad\n");
#endif
	switch (format&0x8018) {

		case AUDIO_U8: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			for ( i=cvt->len_cvt/4; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				src += 4;
				dst += 2;
			}
		}
		break;

		case AUDIO_S8: {
			Sint8 *src, *dst;

			src = (Sint8 *)cvt->buf;
			dst = (Sint8 *)cvt->buf;
			for ( i=cvt->len_cvt/4; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				src += 4;
				dst += 2;
			}
		}
		break;

		case AUDIO_U16: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/8; i; --i ) {
					lsample = (Uint16)((src[0]<<8)|src[1]);
					rsample = (Uint16)((src[2]<<8)|src[3]);
						dst[1] = (lsample&0xFF);
						lsample >>= 8;
						dst[0] = (lsample&0xFF);
						dst[3] = (rsample&0xFF);
						rsample >>= 8;
						dst[2] = (rsample&0xFF);
					src += 8;
					dst += 4;
				}
			} else {
				for ( i=cvt->len_cvt/8; i; --i ) {
					lsample = (Uint16)((src[1]<<8)|src[0]);
					rsample = (Uint16)((src[3]<<8)|src[2]);
						dst[0] = (lsample&0xFF);
						lsample >>= 8;
						dst[1] = (lsample&0xFF);
						dst[2] = (rsample&0xFF);
						rsample >>= 8;
						dst[3] = (rsample&0xFF);
					src += 8;
					dst += 4;
				}
			}
		}
		break;

		case AUDIO_S16: {
			Uint8 *src, *dst;

			src = cvt->buf;
			dst = cvt->buf;
			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/8; i; --i ) {
					lsample = (Sint16)((src[0]<<8)|src[1]);
					rsample = (Sint16)((src[2]<<8)|src[3]);
						dst[1] = (lsample&0xFF);
						lsample >>= 8;
						dst[0] = (lsample&0xFF);
						dst[3] = (rsample&0xFF);
						rsample >>= 8;
						dst[2] = (rsample&0xFF);
					src += 8;
					dst += 4;
				}
			} else {
				for ( i=cvt->len_cvt/8; i; --i ) {
					lsample = (Sint16)((src[1]<<8)|src[0]);
					rsample = (Sint16)((src[3]<<8)|src[2]);
						dst[0] = (lsample&0xFF);
						lsample >>= 8;
						dst[1] = (lsample&0xFF);
						dst[2] = (rsample&0xFF);
						rsample >>= 8;
						dst[3] = (rsample&0xFF);
					src += 8;
					dst += 4;
				}
			}
		}
		break;
	}
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_ConvertStereo(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting to stereo\n");
#endif
	if ( (format & 0xFF) == 16 ) {
		Uint16 *src, *dst;

		src = (Uint16 *)(cvt->buf+cvt->len_cvt);
		dst = (Uint16 *)(cvt->buf+cvt->len_cvt*2);
		for ( i=cvt->len_cvt/2; i; --i ) {
			dst -= 2;
			src -= 1;
			dst[0] = src[0];
			dst[1] = src[0];
		}
	} else {
		Uint8 *src, *dst;

		src = cvt->buf+cvt->len_cvt;
		dst = cvt->buf+cvt->len_cvt*2;
		for ( i=cvt->len_cvt; i; --i ) {
			dst -= 2;
			src -= 1;
			dst[0] = src[0];
			dst[1] = src[0];
		}
	}
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_ConvertSurround(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting stereo to surround\n");
#endif
	switch (format&0x8018) {

		case AUDIO_U8: {
			Uint8 *src, *dst, lf, rf, ce;

			src = (Uint8 *)(cvt->buf+cvt->len_cvt);
			dst = (Uint8 *)(cvt->buf+cvt->len_cvt*3);
			for ( i=cvt->len_cvt; i; --i ) {
				dst -= 6;
				src -= 2;
				lf = src[0];
				rf = src[1];
				ce = (lf/2) + (rf/2);
				dst[0] = lf;
				dst[1] = rf;
				dst[2] = lf - ce;
				dst[3] = rf - ce;
				dst[4] = ce;
				dst[5] = ce;
			}
		}
		break;

		case AUDIO_S8: {
			Sint8 *src, *dst, lf, rf, ce;

			src = (Sint8 *)cvt->buf+cvt->len_cvt;
			dst = (Sint8 *)cvt->buf+cvt->len_cvt*3;
			for ( i=cvt->len_cvt; i; --i ) {
				dst -= 6;
				src -= 2;
				lf = src[0];
				rf = src[1];
				ce = (lf/2) + (rf/2);
				dst[0] = lf;
				dst[1] = rf;
				dst[2] = lf - ce;
				dst[3] = rf - ce;
				dst[4] = ce;
				dst[5] = ce;
			}
		}
		break;

		case AUDIO_U16: {
			Uint8 *src, *dst;
			Uint16 lf, rf, ce, lr, rr;

			src = cvt->buf+cvt->len_cvt;
			dst = cvt->buf+cvt->len_cvt*3;

			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 12;
					src -= 4;
					lf = (Uint16)((src[0]<<8)|src[1]);
					rf = (Uint16)((src[2]<<8)|src[3]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[1] = (lf&0xFF);
						dst[0] = ((lf>>8)&0xFF);
						dst[3] = (rf&0xFF);
						dst[2] = ((rf>>8)&0xFF);

						dst[1+4] = (lr&0xFF);
						dst[0+4] = ((lr>>8)&0xFF);
						dst[3+4] = (rr&0xFF);
						dst[2+4] = ((rr>>8)&0xFF);

						dst[1+8] = (ce&0xFF);
						dst[0+8] = ((ce>>8)&0xFF);
						dst[3+8] = (ce&0xFF);
						dst[2+8] = ((ce>>8)&0xFF);
				}
			} else {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 12;
					src -= 4;
					lf = (Uint16)((src[1]<<8)|src[0]);
					rf = (Uint16)((src[3]<<8)|src[2]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[0] = (lf&0xFF);
						dst[1] = ((lf>>8)&0xFF);
						dst[2] = (rf&0xFF);
						dst[3] = ((rf>>8)&0xFF);

						dst[0+4] = (lr&0xFF);
						dst[1+4] = ((lr>>8)&0xFF);
						dst[2+4] = (rr&0xFF);
						dst[3+4] = ((rr>>8)&0xFF);

						dst[0+8] = (ce&0xFF);
						dst[1+8] = ((ce>>8)&0xFF);
						dst[2+8] = (ce&0xFF);
						dst[3+8] = ((ce>>8)&0xFF);
				}
			}
		}
		break;

		case AUDIO_S16: {
			Uint8 *src, *dst;
			Sint16 lf, rf, ce, lr, rr;

			src = cvt->buf+cvt->len_cvt;
			dst = cvt->buf+cvt->len_cvt*3;

			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 12;
					src -= 4;
					lf = (Sint16)((src[0]<<8)|src[1]);
					rf = (Sint16)((src[2]<<8)|src[3]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[1] = (lf&0xFF);
						dst[0] = ((lf>>8)&0xFF);
						dst[3] = (rf&0xFF);
						dst[2] = ((rf>>8)&0xFF);

						dst[1+4] = (lr&0xFF);
						dst[0+4] = ((lr>>8)&0xFF);
						dst[3+4] = (rr&0xFF);
						dst[2+4] = ((rr>>8)&0xFF);

						dst[1+8] = (ce&0xFF);
						dst[0+8] = ((ce>>8)&0xFF);
						dst[3+8] = (ce&0xFF);
						dst[2+8] = ((ce>>8)&0xFF);
				}
			} else {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 12;
					src -= 4;
					lf = (Sint16)((src[1]<<8)|src[0]);
					rf = (Sint16)((src[3]<<8)|src[2]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[0] = (lf&0xFF);
						dst[1] = ((lf>>8)&0xFF);
						dst[2] = (rf&0xFF);
						dst[3] = ((rf>>8)&0xFF);

						dst[0+4] = (lr&0xFF);
						dst[1+4] = ((lr>>8)&0xFF);
						dst[2+4] = (rr&0xFF);
						dst[3+4] = ((rr>>8)&0xFF);

						dst[0+8] = (ce&0xFF);
						dst[1+8] = ((ce>>8)&0xFF);
						dst[2+8] = (ce&0xFF);
						dst[3+8] = ((ce>>8)&0xFF);
				}
			}
		}
		break;
	}
	cvt->len_cvt *= 3;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_ConvertSurround_4(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting stereo to quad\n");
#endif
	switch (format&0x8018) {

		case AUDIO_U8: {
			Uint8 *src, *dst, lf, rf, ce;

			src = (Uint8 *)(cvt->buf+cvt->len_cvt);
			dst = (Uint8 *)(cvt->buf+cvt->len_cvt*2);
			for ( i=cvt->len_cvt; i; --i ) {
				dst -= 4;
				src -= 2;
				lf = src[0];
				rf = src[1];
				ce = (lf/2) + (rf/2);
				dst[0] = lf;
				dst[1] = rf;
				dst[2] = lf - ce;
				dst[3] = rf - ce;
			}
		}
		break;

		case AUDIO_S8: {
			Sint8 *src, *dst, lf, rf, ce;

			src = (Sint8 *)cvt->buf+cvt->len_cvt;
			dst = (Sint8 *)cvt->buf+cvt->len_cvt*2;
			for ( i=cvt->len_cvt; i; --i ) {
				dst -= 4;
				src -= 2;
				lf = src[0];
				rf = src[1];
				ce = (lf/2) + (rf/2);
				dst[0] = lf;
				dst[1] = rf;
				dst[2] = lf - ce;
				dst[3] = rf - ce;
			}
		}
		break;

		case AUDIO_U16: {
			Uint8 *src, *dst;
			Uint16 lf, rf, ce, lr, rr;

			src = cvt->buf+cvt->len_cvt;
			dst = cvt->buf+cvt->len_cvt*2;

			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 8;
					src -= 4;
					lf = (Uint16)((src[0]<<8)|src[1]);
					rf = (Uint16)((src[2]<<8)|src[3]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[1] = (lf&0xFF);
						dst[0] = ((lf>>8)&0xFF);
						dst[3] = (rf&0xFF);
						dst[2] = ((rf>>8)&0xFF);

						dst[1+4] = (lr&0xFF);
						dst[0+4] = ((lr>>8)&0xFF);
						dst[3+4] = (rr&0xFF);
						dst[2+4] = ((rr>>8)&0xFF);
				}
			} else {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 8;
					src -= 4;
					lf = (Uint16)((src[1]<<8)|src[0]);
					rf = (Uint16)((src[3]<<8)|src[2]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[0] = (lf&0xFF);
						dst[1] = ((lf>>8)&0xFF);
						dst[2] = (rf&0xFF);
						dst[3] = ((rf>>8)&0xFF);

						dst[0+4] = (lr&0xFF);
						dst[1+4] = ((lr>>8)&0xFF);
						dst[2+4] = (rr&0xFF);
						dst[3+4] = ((rr>>8)&0xFF);
				}
			}
		}
		break;

		case AUDIO_S16: {
			Uint8 *src, *dst;
			Sint16 lf, rf, ce, lr, rr;

			src = cvt->buf+cvt->len_cvt;
			dst = cvt->buf+cvt->len_cvt*2;

			if ( (format & 0x1000) == 0x1000 ) {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 8;
					src -= 4;
					lf = (Sint16)((src[0]<<8)|src[1]);
					rf = (Sint16)((src[2]<<8)|src[3]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[1] = (lf&0xFF);
						dst[0] = ((lf>>8)&0xFF);
						dst[3] = (rf&0xFF);
						dst[2] = ((rf>>8)&0xFF);

						dst[1+4] = (lr&0xFF);
						dst[0+4] = ((lr>>8)&0xFF);
						dst[3+4] = (rr&0xFF);
						dst[2+4] = ((rr>>8)&0xFF);
				}
			} else {
				for ( i=cvt->len_cvt/4; i; --i ) {
					dst -= 8;
					src -= 4;
					lf = (Sint16)((src[1]<<8)|src[0]);
					rf = (Sint16)((src[3]<<8)|src[2]);
					ce = (lf/2) + (rf/2);
					rr = lf - ce;
					lr = rf - ce;
						dst[0] = (lf&0xFF);
						dst[1] = ((lf>>8)&0xFF);
						dst[2] = (rf&0xFF);
						dst[3] = ((rf>>8)&0xFF);

						dst[0+4] = (lr&0xFF);
						dst[1+4] = ((lr>>8)&0xFF);
						dst[2+4] = (rr&0xFF);
						dst[3+4] = ((rr>>8)&0xFF);
				}
			}
		}
		break;
	}
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_Convert16LSB(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting to 16-bit LSB\n");
#endif
	src = cvt->buf+cvt->len_cvt;
	dst = cvt->buf+cvt->len_cvt*2;
	for ( i=cvt->len_cvt; i; --i ) {
		src -= 1;
		dst -= 2;
		dst[1] = *src;
		dst[0] = 0;
	}
	format = ((format & ~0x0008) | AUDIO_U16LSB);
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_Convert16MSB(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting to 16-bit MSB\n");
#endif
	src = cvt->buf+cvt->len_cvt;
	dst = cvt->buf+cvt->len_cvt*2;
	for ( i=cvt->len_cvt; i; --i ) {
		src -= 1;
		dst -= 2;
		dst[0] = *src;
		dst[1] = 0;
	}
	format = ((format & ~0x0008) | AUDIO_U16MSB);
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_Convert8(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting to 8-bit\n");
#endif
	src = cvt->buf;
	dst = cvt->buf;
	if ( (format & 0x1000) != 0x1000 ) { /* Little endian */
		++src;
	}
	for ( i=cvt->len_cvt/2; i; --i ) {
		*dst = *src;
		src += 2;
		dst += 1;
	}
	format = ((format & ~0x9010) | AUDIO_U8);
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_ConvertSign(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *data;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio signedness\n");
#endif
	data = cvt->buf;
	if ( (format & 0xFF) == 16 ) {
		if ( (format & 0x1000) != 0x1000 ) { /* Little endian */
			++data;
		}
		for ( i=cvt->len_cvt/2; i; --i ) {
			*data ^= 0x80;
			data += 2;
		}
	} else {
		for ( i=cvt->len_cvt; i; --i ) {
			*data++ ^= 0x80;
		}
	}
	format = (format ^ 0x8000);
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_ConvertEndian(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *data, tmp;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio endianness\n");
#endif
	data = cvt->buf;
	for ( i=cvt->len_cvt/2; i; --i ) {
		tmp = data[0];
		data[0] = data[1];
		data[1] = tmp;
		data += 2;
	}
	format = (format ^ 0x1000);
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateMUL2(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate * 2\n");
#endif
	src = cvt->buf+cvt->len_cvt;
	dst = cvt->buf+cvt->len_cvt*2;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt; i; --i ) {
				src -= 1;
				dst -= 2;
				dst[0] = src[0];
				dst[1] = src[0];
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/2; i; --i ) {
				src -= 2;
				dst -= 4;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[0];
				dst[3] = src[1];
			}
			break;
	}
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateMUL2_c2(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate * 2\n");
#endif
	src = cvt->buf+cvt->len_cvt;
	dst = cvt->buf+cvt->len_cvt*2;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/2; i; --i ) {
				src -= 2;
				dst -= 4;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[0];
				dst[3] = src[1];
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/4; i; --i ) {
				src -= 4;
				dst -= 8;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[0];
				dst[5] = src[1];
				dst[6] = src[2];
				dst[7] = src[3];
			}
			break;
	}
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateMUL2_c4(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate * 2\n");
#endif
	src = cvt->buf+cvt->len_cvt;
	dst = cvt->buf+cvt->len_cvt*2;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/4; i; --i ) {
				src -= 4;
				dst -= 8;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[0];
				dst[5] = src[1];
				dst[6] = src[2];
				dst[7] = src[3];
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/8; i; --i ) {
				src -= 8;
				dst -= 16;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[4];
				dst[5] = src[5];
				dst[6] = src[6];
				dst[7] = src[7];
				dst[8] = src[0];
				dst[9] = src[1];
				dst[10] = src[2];
				dst[11] = src[3];
				dst[12] = src[4];
				dst[13] = src[5];
				dst[14] = src[6];
				dst[15] = src[7];
			}
			break;
	}
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateMUL2_c6(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate * 2\n");
#endif
	src = cvt->buf+cvt->len_cvt;
	dst = cvt->buf+cvt->len_cvt*2;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/6; i; --i ) {
				src -= 6;
				dst -= 12;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[4];
				dst[5] = src[5];
				dst[6] = src[0];
				dst[7] = src[1];
				dst[8] = src[2];
				dst[9] = src[3];
				dst[10] = src[4];
				dst[11] = src[5];
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/12; i; --i ) {
				src -= 12;
				dst -= 24;
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[4];
				dst[5] = src[5];
				dst[6] = src[6];
				dst[7] = src[7];
				dst[8] = src[8];
				dst[9] = src[9];
				dst[10] = src[10];
				dst[11] = src[11];
				dst[12] = src[0];
				dst[13] = src[1];
				dst[14] = src[2];
				dst[15] = src[3];
				dst[16] = src[4];
				dst[17] = src[5];
				dst[18] = src[6];
				dst[19] = src[7];
				dst[20] = src[8];
				dst[21] = src[9];
				dst[22] = src[10];
				dst[23] = src[11];
			}
			break;
	}
	cvt->len_cvt *= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateDIV2(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate / 2\n");
#endif
	src = cvt->buf;
	dst = cvt->buf;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/2; i; --i ) {
				dst[0] = src[0];
				src += 2;
				dst += 1;
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/4; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				src += 4;
				dst += 2;
			}
			break;
	}
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateDIV2_c2(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate / 2\n");
#endif
	src = cvt->buf;
	dst = cvt->buf;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/4; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				src += 4;
				dst += 2;
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/8; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				src += 8;
				dst += 4;
			}
			break;
	}
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}


/* Convert rate down by multiple of 2, for quad */
void SDLCALL SDL_RateDIV2_c4(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate / 2\n");
#endif
	src = cvt->buf;
	dst = cvt->buf;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/8; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				src += 8;
				dst += 4;
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/16; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[4];
				dst[5] = src[5];
				dst[6] = src[6];
				dst[7] = src[7];
				src += 16;
				dst += 8;
			}
			break;
	}
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateDIV2_c6(SDL_AudioCVT *cvt, Uint16 format)
{
	int i;
	Uint8 *src, *dst;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate / 2\n");
#endif
	src = cvt->buf;
	dst = cvt->buf;
	switch (format & 0xFF) {
		case 8:
			for ( i=cvt->len_cvt/12; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[4];
				dst[5] = src[5];
				src += 12;
				dst += 6;
			}
			break;
		case 16:
			for ( i=cvt->len_cvt/24; i; --i ) {
				dst[0] = src[0];
				dst[1] = src[1];
				dst[2] = src[2];
				dst[3] = src[3];
				dst[4] = src[4];
				dst[5] = src[5];
				dst[6] = src[6];
				dst[7] = src[7];
				dst[8] = src[8];
				dst[9] = src[9];
				dst[10] = src[10];
				dst[11] = src[11];
				src += 24;
				dst += 12;
			}
			break;
	}
	cvt->len_cvt /= 2;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

void SDLCALL SDL_RateSLOW(SDL_AudioCVT *cvt, Uint16 format)
{
	double ipos;
	int i, clen;

#ifdef DEBUG_CONVERT
	fprintf(stderr, "Converting audio rate * %4.4f\n", 1.0/cvt->rate_incr);
#endif
	clen = (int)((double)cvt->len_cvt / cvt->rate_incr);
	if ( cvt->rate_incr > 1.0 ) {
		switch (format & 0xFF) {
			case 8: {
				Uint8 *output;

				output = cvt->buf;
				ipos = 0.0;
				for ( i=clen; i; --i ) {
					*output = cvt->buf[(int)ipos];
					ipos += cvt->rate_incr;
					output += 1;
				}
			}
			break;

			case 16: {
				Uint16 *output;

				clen &= ~1;
				output = (Uint16 *)cvt->buf;
				ipos = 0.0;
				for ( i=clen/2; i; --i ) {
					*output=((Uint16 *)cvt->buf)[(int)ipos];
					ipos += cvt->rate_incr;
					output += 1;
				}
			}
			break;
		}
	} else {
		switch (format & 0xFF) {
			case 8: {
				Uint8 *output;

				output = cvt->buf+clen;
				ipos = (double)cvt->len_cvt;
				for ( i=clen; i; --i ) {
					ipos -= cvt->rate_incr;
					output -= 1;
					*output = cvt->buf[(int)ipos];
				}
			}
			break;

			case 16: {
				Uint16 *output;

				clen &= ~1;
				output = (Uint16 *)(cvt->buf+clen);
				ipos = (double)cvt->len_cvt/2;
				for ( i=clen/2; i; --i ) {
					ipos -= cvt->rate_incr;
					output -= 1;
					*output=((Uint16 *)cvt->buf)[(int)ipos];
				}
			}
			break;
		}
	}
	cvt->len_cvt = clen;
	if ( cvt->filters[++cvt->filter_index] ) {
		cvt->filters[cvt->filter_index](cvt, format);
	}
}

int SDL_ConvertAudio(SDL_AudioCVT *cvt)
{
	if ( cvt->buf == NULL ) {
		SDL_SetError("No buffer allocated for conversion");
		return(-1);
	}
	cvt->len_cvt = cvt->len;
	if ( cvt->filters[0] == NULL ) {
		return(0);
	}
	cvt->filter_index = 0;
	cvt->filters[0](cvt, cvt->src_format);
	return(0);
}

int SDL_BuildAudioCVT(SDL_AudioCVT *cvt,
	Uint16 src_format, Uint8 src_channels, int src_rate,
	Uint16 dst_format, Uint8 dst_channels, int dst_rate)
{
/*printf("Build format %04x->%04x, channels %u->%u, rate %d->%d\n",
		src_format, dst_format, src_channels, dst_channels, src_rate, dst_rate);*/
	/* Start off with no conversion necessary */
	cvt->needed = 0;
	cvt->filter_index = 0;
	cvt->filters[0] = NULL;
	cvt->len_mult = 1;
	cvt->len_ratio = 1.0;
	if ( (src_format & 0x1000) != (dst_format & 0x1000)
	     && ((src_format & 0xff) == 16) && ((dst_format & 0xff) == 16)) {
		cvt->filters[cvt->filter_index++] = SDL_ConvertEndian;
	}
	if ( (src_format & 0x8000) != (dst_format & 0x8000) ) {
		cvt->filters[cvt->filter_index++] = SDL_ConvertSign;
	}
	if ( (src_format & 0xFF) != (dst_format & 0xFF) ) {
		switch (dst_format&0x10FF) {
			case AUDIO_U8:
				cvt->filters[cvt->filter_index++] =
							 SDL_Convert8;
				cvt->len_ratio /= 2;
				break;
			case AUDIO_U16LSB:
				cvt->filters[cvt->filter_index++] =
							SDL_Convert16LSB;
				cvt->len_mult *= 2;
				cvt->len_ratio *= 2;
				break;
			case AUDIO_U16MSB:
				cvt->filters[cvt->filter_index++] =
							SDL_Convert16MSB;
				cvt->len_mult *= 2;
				cvt->len_ratio *= 2;
				break;
		}
	}
	if ( src_channels != dst_channels ) {
		if ( (src_channels == 1) && (dst_channels > 1) ) {
			cvt->filters[cvt->filter_index++] = 
						SDL_ConvertStereo;
			cvt->len_mult *= 2;
			src_channels = 2;
			cvt->len_ratio *= 2;
		}
		if ( (src_channels == 2) &&
				(dst_channels == 6) ) {
			cvt->filters[cvt->filter_index++] =
						 SDL_ConvertSurround;
			src_channels = 6;
			cvt->len_mult *= 3;
			cvt->len_ratio *= 3;
		}
		if ( (src_channels == 2) &&
				(dst_channels == 4) ) {
			cvt->filters[cvt->filter_index++] =
						 SDL_ConvertSurround_4;
			src_channels = 4;
			cvt->len_mult *= 2;
			cvt->len_ratio *= 2;
		}
		while ( (src_channels*2) <= dst_channels ) {
			cvt->filters[cvt->filter_index++] = 
						SDL_ConvertStereo;
			cvt->len_mult *= 2;
			src_channels *= 2;
			cvt->len_ratio *= 2;
		}
		if ( (src_channels == 6) &&
				(dst_channels <= 2) ) {
			cvt->filters[cvt->filter_index++] =
						 SDL_ConvertStrip;
			src_channels = 2;
			cvt->len_ratio /= 3;
		}
		if ( (src_channels == 6) &&
				(dst_channels == 4) ) {
			cvt->filters[cvt->filter_index++] =
						 SDL_ConvertStrip_2;
			src_channels = 4;
			cvt->len_ratio /= 2;
		}
		while ( ((src_channels%2) == 0) &&
				((src_channels/2) >= dst_channels) ) {
			cvt->filters[cvt->filter_index++] =
						 SDL_ConvertMono;
			src_channels /= 2;
			cvt->len_ratio /= 2;
		}
		if ( src_channels != dst_channels ) {
			
		}
	}
	cvt->rate_incr = 0.0;
	if ( (src_rate/100) != (dst_rate/100) ) {
		Uint32 hi_rate, lo_rate;
		int len_mult;
		double len_ratio;
		void (SDLCALL *rate_cvt)(SDL_AudioCVT *cvt, Uint16 format);
		if ( src_rate > dst_rate ) {
			hi_rate = src_rate;
			lo_rate = dst_rate;
			switch (src_channels) {
				case 1: rate_cvt = SDL_RateDIV2; break;
				case 2: rate_cvt = SDL_RateDIV2_c2; break;
				case 4: rate_cvt = SDL_RateDIV2_c4; break;
				case 6: rate_cvt = SDL_RateDIV2_c6; break;
				default: return -1;
			}
			len_mult = 1;
			len_ratio = 0.5;
		} else {
			hi_rate = dst_rate;
			lo_rate = src_rate;
			switch (src_channels) {
				case 1: rate_cvt = SDL_RateMUL2; break;
				case 2: rate_cvt = SDL_RateMUL2_c2; break;
				case 4: rate_cvt = SDL_RateMUL2_c4; break;
				case 6: rate_cvt = SDL_RateMUL2_c6; break;
				default: return -1;
			}
			len_mult = 2;
			len_ratio = 2.0;
		}
		while ( ((lo_rate*2)/100) <= (hi_rate/100) ) {
			cvt->filters[cvt->filter_index++] = rate_cvt;
			cvt->len_mult *= len_mult;
			lo_rate *= 2;
			cvt->len_ratio *= len_ratio;
		}
		if ( (lo_rate/100) != (hi_rate/100) ) {
#if 1
			/* The problem with this is that if the input buffer is
			   say 1K, and the conversion rate is say 1.1, then the
			   output buffer is 1.1K, which may not be an acceptable
			   buffer size for the audio driver (not a power of 2)
			*/
			/* For now, punt and hope the rate distortion isn't great.
			*/
#else
			if ( src_rate < dst_rate ) {
				cvt->rate_incr = (double)lo_rate/hi_rate;
				cvt->len_mult *= 2;
				cvt->len_ratio /= cvt->rate_incr;
			} else {
				cvt->rate_incr = (double)hi_rate/lo_rate;
				cvt->len_ratio *= cvt->rate_incr;
			}
			cvt->filters[cvt->filter_index++] = SDL_RateSLOW;
#endif
		}
	}
	if ( cvt->filter_index != 0 ) {
		cvt->needed = 1;
		cvt->src_format = src_format;
		cvt->dst_format = dst_format;
		cvt->len = 0;
		cvt->buf = NULL;
		cvt->filters[cvt->filter_index] = NULL;
	}
	return(cvt->needed);
}



