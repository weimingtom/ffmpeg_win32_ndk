#include "SDL_thread.h"


#include "SDL_error_c.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <process.h>

typedef HANDLE SYS_ThreadHandle;
struct SDL_Thread {
	Uint32 threadid;
	SYS_ThreadHandle handle;
	int status;
	SDL_error errbuf;
	void *data;
};
extern void SDL_RunThread(void *data);











struct SDL_mutex {
	HANDLE id;
};
SDL_mutex *SDL_CreateMutex(void)
{
	SDL_mutex *mutex;
	mutex = (SDL_mutex *)SDL_malloc(sizeof(*mutex));
	if ( mutex ) {
		mutex->id = CreateMutex(NULL, FALSE, NULL);
		if ( ! mutex->id ) {
			SDL_SetError("Couldn't create mutex");
			SDL_free(mutex);
			mutex = NULL;
		}
	} else {
		SDL_OutOfMemory();
	}
	return(mutex);
}
void SDL_DestroyMutex(SDL_mutex *mutex)
{
	if ( mutex ) {
		if ( mutex->id ) {
			CloseHandle(mutex->id);
			mutex->id = 0;
		}
		SDL_free(mutex);
	}
}
int SDL_mutexP(SDL_mutex *mutex)
{
	if ( mutex == NULL ) {
		SDL_SetError("Passed a NULL mutex");
		return -1;
	}
	if ( WaitForSingleObject(mutex->id, INFINITE) == WAIT_FAILED ) {
		SDL_SetError("Couldn't wait on mutex");
		return -1;
	}
	return(0);
}
int SDL_mutexV(SDL_mutex *mutex)
{
	if ( mutex == NULL ) {
		SDL_SetError("Passed a NULL mutex");
		return -1;
	}
	if ( ReleaseMutex(mutex->id) == FALSE ) {
		SDL_SetError("Couldn't release mutex");
		return -1;
	}
	return(0);
}











struct SDL_semaphore {
	HANDLE id;
	volatile LONG count;
};
SDL_sem *SDL_CreateSemaphore(Uint32 initial_value)
{
	SDL_sem *sem;
	sem = (SDL_sem *)SDL_malloc(sizeof(*sem));
	if ( sem ) {
		sem->id = CreateSemaphore(NULL, initial_value, 32*1024, NULL);
		sem->count = (LONG) initial_value;
		if ( ! sem->id ) {
			SDL_SetError("Couldn't create semaphore");
			SDL_free(sem);
			sem = NULL;
		}
	} else {
		SDL_OutOfMemory();
	}
	return(sem);
}
void SDL_DestroySemaphore(SDL_sem *sem)
{
	if ( sem ) {
		if ( sem->id ) {
			CloseHandle(sem->id);
			sem->id = 0;
		}
		SDL_free(sem);
	}
}
int SDL_SemWaitTimeout(SDL_sem *sem, Uint32 timeout)
{
	int retval;
	DWORD dwMilliseconds;
	if ( ! sem ) {
		SDL_SetError("Passed a NULL sem");
		return -1;
	}
	if ( timeout == SDL_MUTEX_MAXWAIT ) {
		dwMilliseconds = INFINITE;
	} else {
		dwMilliseconds = (DWORD)timeout;
	}
	switch (WaitForSingleObject(sem->id, dwMilliseconds)) {
	case WAIT_OBJECT_0:
		InterlockedDecrement(&sem->count);
		retval = 0;
		break;
	
	case WAIT_TIMEOUT:
		retval = SDL_MUTEX_TIMEDOUT;
		break;
	
	default:
		SDL_SetError("WaitForSingleObject() failed");
		retval = -1;
		break;
	}
	return retval;
}
int SDL_SemTryWait(SDL_sem *sem)
{
	return SDL_SemWaitTimeout(sem, 0);
}
int SDL_SemWait(SDL_sem *sem)
{
	return SDL_SemWaitTimeout(sem, SDL_MUTEX_MAXWAIT);
}
Uint32 SDL_SemValue(SDL_sem *sem)
{
	if ( ! sem ) {
		SDL_SetError("Passed a NULL sem");
		return 0;
	}
	return (Uint32) sem->count;
}
int SDL_SemPost(SDL_sem *sem)
{
	if ( ! sem ) {
		SDL_SetError("Passed a NULL sem");
		return -1;
	}
	InterlockedIncrement(&sem->count);
	if ( ReleaseSemaphore(sem->id, 1, NULL) == FALSE ) {
		InterlockedDecrement(&sem->count);
		SDL_SetError("ReleaseSemaphore() failed");
		return -1;
	}
	return 0;
}








struct SDL_cond
{
	SDL_mutex *lock;
	int waiting;
	int signals;
	SDL_sem *wait_sem;
	SDL_sem *wait_done;
};
SDL_cond * SDL_CreateCond(void)
{
	SDL_cond *cond;
	cond = (SDL_cond *) SDL_malloc(sizeof(SDL_cond));
	if ( cond ) {
		cond->lock = SDL_CreateMutex();
		cond->wait_sem = SDL_CreateSemaphore(0);
		cond->wait_done = SDL_CreateSemaphore(0);
		cond->waiting = cond->signals = 0;
		if ( ! cond->lock || ! cond->wait_sem || ! cond->wait_done ) {
			SDL_DestroyCond(cond);
			cond = NULL;
		}
	} else {
		SDL_OutOfMemory();
	}
	return(cond);
}
void SDL_DestroyCond(SDL_cond *cond)
{
	if ( cond ) {
		if ( cond->wait_sem ) {
			SDL_DestroySemaphore(cond->wait_sem);
		}
		if ( cond->wait_done ) {
			SDL_DestroySemaphore(cond->wait_done);
		}
		if ( cond->lock ) {
			SDL_DestroyMutex(cond->lock);
		}
		SDL_free(cond);
	}
}
int SDL_CondSignal(SDL_cond *cond)
{
	if ( ! cond ) {
		SDL_SetError("Passed a NULL condition variable");
		return -1;
	}
	SDL_LockMutex(cond->lock);
	if ( cond->waiting > cond->signals ) {
		++cond->signals;
		SDL_SemPost(cond->wait_sem);
		SDL_UnlockMutex(cond->lock);
		SDL_SemWait(cond->wait_done);
	} else {
		SDL_UnlockMutex(cond->lock);
	}
	return 0;
}
int SDL_CondBroadcast(SDL_cond *cond)
{
	if ( ! cond ) {
		SDL_SetError("Passed a NULL condition variable");
		return -1;
	}
	SDL_LockMutex(cond->lock);
	if ( cond->waiting > cond->signals ) {
		int i, num_waiting;
		num_waiting = (cond->waiting - cond->signals);
		cond->signals = cond->waiting;
		for ( i=0; i<num_waiting; ++i ) {
			SDL_SemPost(cond->wait_sem);
		}
		SDL_UnlockMutex(cond->lock);
		for ( i=0; i<num_waiting; ++i ) {
			SDL_SemWait(cond->wait_done);
		}
	} else {
		SDL_UnlockMutex(cond->lock);
	}
	return 0;
}
int SDL_CondWaitTimeout(SDL_cond *cond, SDL_mutex *mutex, Uint32 ms)
{
	int retval;
	if ( ! cond ) {
		SDL_SetError("Passed a NULL condition variable");
		return -1;
	}
	SDL_LockMutex(cond->lock);
	++cond->waiting;
	SDL_UnlockMutex(cond->lock);
	SDL_UnlockMutex(mutex);
	if ( ms == SDL_MUTEX_MAXWAIT ) {
		retval = SDL_SemWait(cond->wait_sem);
	} else {
		retval = SDL_SemWaitTimeout(cond->wait_sem, ms);
	}
	SDL_LockMutex(cond->lock);
	if ( cond->signals > 0 ) {
		if ( retval > 0 ) {
			SDL_SemWait(cond->wait_sem);
		}
		SDL_SemPost(cond->wait_done);
		--cond->signals;
	}
	--cond->waiting;
	SDL_UnlockMutex(cond->lock);
	SDL_LockMutex(mutex);
	return retval;
}
int SDL_CondWait(SDL_cond *cond, SDL_mutex *mutex)
{
	return SDL_CondWaitTimeout(cond, mutex, SDL_MUTEX_MAXWAIT);
}






















extern int SDL_SYS_CreateThread(SDL_Thread *thread, void *args);
extern void SDL_SYS_SetupThread(void);
extern void SDL_SYS_WaitThread(SDL_Thread *thread);
extern void SDL_SYS_KillThread(SDL_Thread *thread);

typedef uintptr_t (__cdecl *pfnSDL_CurrentBeginThread) (void *, unsigned,
        unsigned (__stdcall *func)(void *), void *arg, 
        unsigned, unsigned *threadID);
typedef void (__cdecl *pfnSDL_CurrentEndThread)(unsigned code);
typedef struct ThreadStartParms
{
  void *args;
  pfnSDL_CurrentEndThread pfnCurrentEndThread;
} tThreadStartParms, *pThreadStartParms;
static DWORD RunThread(void *data)
{
  pThreadStartParms pThreadParms = (pThreadStartParms)data;
  pfnSDL_CurrentEndThread pfnCurrentEndThread = NULL;
  SDL_RunThread(pThreadParms->args);
  if (pThreadParms)
  {
    pfnCurrentEndThread = pThreadParms->pfnCurrentEndThread;
    SDL_free(pThreadParms);
  }
  if (pfnCurrentEndThread)
    (*pfnCurrentEndThread)(0);
  return(0);
}
static DWORD WINAPI RunThreadViaCreateThread(LPVOID data)
{
  return RunThread(data);
}
static unsigned __stdcall RunThreadViaBeginThreadEx(void *data)
{
  return (unsigned) RunThread(data);
}
int SDL_SYS_CreateThread(SDL_Thread *thread, void *args)
{
	pfnSDL_CurrentBeginThread pfnBeginThread = _beginthreadex;
	pfnSDL_CurrentEndThread pfnEndThread = _endthreadex;
	pThreadStartParms pThreadParms = (pThreadStartParms)SDL_malloc(sizeof(tThreadStartParms));
	if (!pThreadParms) {
		SDL_OutOfMemory();
		return(-1);
	}
	pThreadParms->pfnCurrentEndThread = pfnEndThread;
	pThreadParms->args = args;
	if (pfnBeginThread) {
		unsigned threadid = 0;
		thread->handle = (SYS_ThreadHandle)
				((size_t) pfnBeginThread(NULL, 0, RunThreadViaBeginThreadEx,
										 pThreadParms, 0, &threadid));
	} else {
		DWORD threadid = 0;
		thread->handle = CreateThread(NULL, 0, RunThreadViaCreateThread, pThreadParms, 0, &threadid);
	}
	if (thread->handle == NULL) {
		SDL_SetError("Not enough resources to create thread");
		return(-1);
	}
	return(0);
}
void SDL_SYS_SetupThread(void)
{
	return;
}
Uint32 SDL_ThreadID(void)
{
	return((Uint32)GetCurrentThreadId());
}
void SDL_SYS_WaitThread(SDL_Thread *thread)
{
	WaitForSingleObject(thread->handle, INFINITE);
	CloseHandle(thread->handle);
}
void SDL_SYS_KillThread(SDL_Thread *thread)
{
	TerminateThread(thread->handle, FALSE);
}




#define ARRAY_CHUNKSIZE	32

static int SDL_maxthreads = 0;
static int SDL_numthreads = 0;
static SDL_Thread **SDL_Threads = NULL;
static SDL_mutex *thread_lock = NULL;

int SDL_ThreadsInit(void)
{
	int retval;
	retval = 0;
	thread_lock = SDL_CreateMutex();
	if ( thread_lock == NULL ) {
		retval = -1;
	}
	return(retval);
}

void SDL_ThreadsQuit(void)
{
	SDL_mutex *mutex;
	mutex = thread_lock;
	thread_lock = NULL;
	if ( mutex != NULL ) {
		SDL_DestroyMutex(mutex);
	}
}

static void SDL_AddThread(SDL_Thread *thread)
{
	if ( !thread_lock ) {
		if ( SDL_ThreadsInit() < 0 ) {
			return;
		}
	}
	SDL_mutexP(thread_lock);
#ifdef DEBUG_THREADS
	printf("Adding thread (%d already - %d max)\n",
			SDL_numthreads, SDL_maxthreads);
#endif
	if ( SDL_numthreads == SDL_maxthreads ) {
		SDL_Thread **threads;
		threads = (SDL_Thread **)SDL_realloc(SDL_Threads,
			(SDL_maxthreads+ARRAY_CHUNKSIZE)*(sizeof *threads));
		if ( threads == NULL ) {
			SDL_OutOfMemory();
			goto done;
		}
		SDL_maxthreads += ARRAY_CHUNKSIZE;
		SDL_Threads = threads;
	}
	SDL_Threads[SDL_numthreads++] = thread;
done:
	SDL_mutexV(thread_lock);
}

static void SDL_DelThread(SDL_Thread *thread)
{
	int i;
	if ( !thread_lock ) {
		return;
	}
	SDL_mutexP(thread_lock);
	for ( i=0; i<SDL_numthreads; ++i ) {
		if ( thread == SDL_Threads[i] ) {
			break;
		}
	}
	if ( i < SDL_numthreads ) {
		if ( --SDL_numthreads > 0 ) {
			while ( i < SDL_numthreads ) {
				SDL_Threads[i] = SDL_Threads[i+1];
				++i;
			}
		} else {
			SDL_maxthreads = 0;
			SDL_free(SDL_Threads);
			SDL_Threads = NULL;
		}
#ifdef DEBUG_THREADS
		printf("Deleting thread (%d left - %d max)\n",
				SDL_numthreads, SDL_maxthreads);
#endif
	}
	SDL_mutexV(thread_lock);
}

static SDL_error SDL_global_error;

SDL_error *SDL_GetErrBuf(void)
{
	SDL_error *errbuf;
	errbuf = &SDL_global_error;
	if ( SDL_Threads ) {
		int i;
		Uint32 this_thread;
		this_thread = SDL_ThreadID();
		SDL_mutexP(thread_lock);
		for ( i=0; i<SDL_numthreads; ++i ) {
			if ( this_thread == SDL_Threads[i]->threadid ) {
				errbuf = &SDL_Threads[i]->errbuf;
				break;
			}
		}
		SDL_mutexV(thread_lock);
	}
	return(errbuf);
}

typedef struct {
	int (SDLCALL *func)(void *);
	void *data;
	SDL_Thread *info;
	SDL_sem *wait;
} thread_args;

void SDL_RunThread(void *data)
{
	thread_args *args;
	int (SDLCALL *userfunc)(void *);
	void *userdata;
	int *statusloc;
	SDL_SYS_SetupThread();
	args = (thread_args *)data;
	args->info->threadid = SDL_ThreadID();
	userfunc = args->func;
	userdata = args->data;
	statusloc = &args->info->status;
	SDL_SemPost(args->wait);
	*statusloc = userfunc(userdata);
}

DECLSPEC SDL_Thread * SDLCALL SDL_CreateThread(int (SDLCALL *fn)(void *), void *data)
{
	SDL_Thread *thread;
	thread_args *args;
	int ret;
	thread = (SDL_Thread *)SDL_malloc(sizeof(*thread));
	if ( thread == NULL ) {
		SDL_OutOfMemory();
		return(NULL);
	}
	SDL_memset(thread, 0, (sizeof *thread));
	thread->status = -1;
	args = (thread_args *)SDL_malloc(sizeof(*args));
	if ( args == NULL ) {
		SDL_OutOfMemory();
		SDL_free(thread);
		return(NULL);
	}
	args->func = fn;
	args->data = data;
	args->info = thread;
	args->wait = SDL_CreateSemaphore(0);
	if ( args->wait == NULL ) {
		SDL_free(thread);
		SDL_free(args);
		return(NULL);
	}
	SDL_AddThread(thread);
	ret = SDL_SYS_CreateThread(thread, args);
	if ( ret >= 0 ) {
		SDL_SemWait(args->wait);
	} else {
		SDL_DelThread(thread);
		SDL_free(thread);
		thread = NULL;
	}
	SDL_DestroySemaphore(args->wait);
	SDL_free(args);
	return(thread);
}

void SDL_WaitThread(SDL_Thread *thread, int *status)
{
	if ( thread ) {
		SDL_SYS_WaitThread(thread);
		if ( status ) {
			*status = thread->status;
		}
		SDL_DelThread(thread);
		SDL_free(thread);
	}
}

Uint32 SDL_GetThreadID(SDL_Thread *thread)
{
	Uint32 id;
	if ( thread ) {
		id = thread->threadid;
	} else {
		id = SDL_ThreadID();
	}
	return(id);
}

void SDL_KillThread(SDL_Thread *thread)
{
	if ( thread ) {
		SDL_SYS_KillThread(thread);
		SDL_WaitThread(thread, NULL);
	}
}
