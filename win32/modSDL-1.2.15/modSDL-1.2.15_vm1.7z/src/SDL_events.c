//#include "SDL_config.h"
#include "SDL.h"
//#include "SDL_syswm.h"
#include "SDL_events.h"

#define DEBUG_EVENTS 0
#define DEBUG_PEEP_EVENTS 0
//SDL_SYSWMEVENT

SDL_EventFilter SDL_EventOK = NULL;
Uint8 SDL_ProcessEvents[SDL_NUMEVENTS];
static Uint32 SDL_eventstate = 0;

#define MAXEVENTS	128
static struct {
	SDL_mutex *lock;
	int active;
	int head;
	int tail;
	SDL_Event event[MAXEVENTS];
} SDL_EventQ;

static struct {
	SDL_mutex *lock;
	int safe;
} SDL_EventLock;

static SDL_Thread *SDL_EventThread = NULL;
static Uint32 event_thread;

void SDL_Lock_EventThread(void)
{
	if ( SDL_EventThread && (SDL_ThreadID() != event_thread) ) {
		SDL_mutexP(SDL_EventLock.lock);
		while ( ! SDL_EventLock.safe ) {
			SDL_Delay(1);
		}
	}
}
void SDL_Unlock_EventThread(void)
{
	if ( SDL_EventThread && (SDL_ThreadID() != event_thread) ) {
		SDL_mutexV(SDL_EventLock.lock);
	}
}

static int SDLCALL SDL_GobbleEvents(void *unused)
{
	event_thread = SDL_ThreadID();
	while ( SDL_EventQ.active ) {
		SDL_EventLock.safe = 1;
		SDL_Delay(1);
		SDL_mutexP(SDL_EventLock.lock);
		SDL_EventLock.safe = 0;
		SDL_mutexV(SDL_EventLock.lock);
	}
	event_thread = 0;
	return(0);
}

static int SDL_StartEventThread(Uint32 flags)
{
	SDL_EventThread = NULL;
	SDL_memset(&SDL_EventLock, 0, sizeof(SDL_EventLock));
	SDL_EventQ.lock = SDL_CreateMutex();
	if ( SDL_EventQ.lock == NULL ) {
		return(-1);
	}
	SDL_EventQ.active = 1;
	if ( (flags&SDL_INIT_EVENTTHREAD) == SDL_INIT_EVENTTHREAD ) {
		SDL_EventLock.lock = SDL_CreateMutex();
		if ( SDL_EventLock.lock == NULL ) {
			return(-1);
		}
		SDL_EventLock.safe = 0;
		SDL_EventThread = SDL_CreateThread(SDL_GobbleEvents, NULL);
		if ( SDL_EventThread == NULL ) {
			return(-1);
		}
	} else {
		event_thread = 0;
	}
	return(0);
}

static void SDL_StopEventThread(void)
{
	SDL_EventQ.active = 0;
	if ( SDL_EventThread ) {
		SDL_WaitThread(SDL_EventThread, NULL);
		SDL_EventThread = NULL;
		SDL_DestroyMutex(SDL_EventLock.lock);
		SDL_EventLock.lock = NULL;
	}
	SDL_DestroyMutex(SDL_EventQ.lock);
	SDL_EventQ.lock = NULL;
}

Uint32 SDL_EventThreadID(void)
{
	return(event_thread);
}

void SDL_StopEventLoop(void)
{
	SDL_StopEventThread();
	SDL_EventQ.head = 0;
	SDL_EventQ.tail = 0;
}

int SDL_StartEventLoop(Uint32 flags)
{
	int retcode;
#if DEBUG_EVENTS
	printf("SDL_StartEventLoop() begin...\n");
#endif
	SDL_EventThread = NULL;
	SDL_EventQ.lock = NULL;
	SDL_StopEventLoop();
	SDL_EventOK = NULL;
	SDL_memset(SDL_ProcessEvents,SDL_ENABLE,sizeof(SDL_ProcessEvents));
	SDL_eventstate = ~0;
	retcode = 0;
	if ( retcode < 0 ) {
		return(-1);
	}
	if ( SDL_StartEventThread(flags) < 0 ) {
		SDL_StopEventLoop();
		return(-1);
	}
	return(0);
}

static int SDL_AddEvent(SDL_Event *event)
{
	int tail, added;
#if DEBUG_EVENTS
	printf("SDL_PeepEvents->SDL_AddEvent addevent...\n");
#endif
	tail = (SDL_EventQ.tail+1)%MAXEVENTS;
	if ( tail == SDL_EventQ.head ) {
		added = 0;
	} else {
		SDL_EventQ.event[SDL_EventQ.tail] = *event;
		SDL_EventQ.tail = tail;
		added = 1;
	}
	return(added);
}

static int SDL_CutEvent(int spot)
{
	if ( spot == SDL_EventQ.head ) {
		SDL_EventQ.head = (SDL_EventQ.head+1)%MAXEVENTS;
		return(SDL_EventQ.head);
	} else
	if ( (spot+1)%MAXEVENTS == SDL_EventQ.tail ) {
		SDL_EventQ.tail = spot;
		return(SDL_EventQ.tail);
	} else
	{
		int here, next;
		if ( --SDL_EventQ.tail < 0 ) {
			SDL_EventQ.tail = MAXEVENTS-1;
		}
		for ( here=spot; here != SDL_EventQ.tail; here = next ) {
			next = (here+1)%MAXEVENTS;
			SDL_EventQ.event[here] = SDL_EventQ.event[next];
		}
		return(spot);
	}
}

int SDL_PeepEvents(SDL_Event *events, int numevents, SDL_eventaction action,
								Uint32 mask)
{
	int i, used;
	if ( ! SDL_EventQ.active ) {
		return(-1);
	}
#if DEBUG_PEEP_EVENTS
	printf("SDL_PeepEvents : SDL_EventQ is active...\n");
#endif
	used = 0;
	if ( SDL_mutexP(SDL_EventQ.lock) == 0 ) {
		if ( action == SDL_ADDEVENT ) {
			for ( i=0; i<numevents; ++i ) {
				used += SDL_AddEvent(&events[i]);
			}
		} else {
			SDL_Event tmpevent;
			int spot;
			if ( events == NULL ) {
				action = SDL_PEEKEVENT;
				numevents = 1;
				events = &tmpevent;
			}
			spot = SDL_EventQ.head;
			while ((used < numevents)&&(spot != SDL_EventQ.tail)) {
				if ( mask & SDL_EVENTMASK(SDL_EventQ.event[spot].type) ) {
					events[used++] = SDL_EventQ.event[spot];
					if ( action == SDL_GETEVENT ) {
						spot = SDL_CutEvent(spot);
					} else {
						spot = (spot+1)%MAXEVENTS;
					}
				} else {
					spot = (spot+1)%MAXEVENTS;
				}
			}
		}
		SDL_mutexV(SDL_EventQ.lock);
	} else {
		SDL_SetError("Couldn't lock event queue");
		used = -1;
	}
	return(used);
}

void SDL_PumpEvents(void)
{
	if ( !SDL_EventThread ) {
		
	}
}

int SDL_PollEvent (SDL_Event *event)
{
	SDL_PumpEvents();
	if ( SDL_PeepEvents(event, 1, SDL_GETEVENT, SDL_ALLEVENTS) <= 0 )
		return 0;
	return 1;
}

int SDL_WaitEvent (SDL_Event *event)
{
	while ( 1 ) {
		SDL_PumpEvents();
		switch(SDL_PeepEvents(event, 1, SDL_GETEVENT, SDL_ALLEVENTS)) {
		    case -1: return 0;
		    case 1: return 1;
		    case 0: SDL_Delay(10);
		}
	}
}

int SDL_PushEvent(SDL_Event *event)
{
#if DEBUG_EVENTS
	printf("SDL_PushEvent...\n");
#endif
	if ( SDL_PeepEvents(event, 1, SDL_ADDEVENT, 0) <= 0 )
		return -1;
	return 0;
}

void SDL_SetEventFilter (SDL_EventFilter filter)
{
	SDL_Event bitbucket;
	SDL_EventOK = filter;
	while ( SDL_PollEvent(&bitbucket) > 0 )
		;
}

SDL_EventFilter SDL_GetEventFilter(void)
{
	return(SDL_EventOK);
}

Uint8 SDL_EventState (Uint8 type, int state)
{
	SDL_Event bitbucket;
	Uint8 current_state;
	if ( type == 0xFF ) {
		current_state = SDL_IGNORE;
		for ( type=0; type<SDL_NUMEVENTS; ++type ) {
			if ( SDL_ProcessEvents[type] != SDL_IGNORE ) {
				current_state = SDL_ENABLE;
			}
			SDL_ProcessEvents[type] = state;
			if ( state == SDL_ENABLE ) {
				SDL_eventstate |= (0x00000001 << (type));
			} else {
				SDL_eventstate &= ~(0x00000001 << (type));
			}
		}
		while ( SDL_PollEvent(&bitbucket) > 0 )
			;
		return(current_state);
	}
	current_state = SDL_ProcessEvents[type];
	switch (state) {
		case SDL_IGNORE:
		case SDL_ENABLE:
			/* Set state and discard pending events */
			SDL_ProcessEvents[type] = state;
			if ( state == SDL_ENABLE ) {
				SDL_eventstate |= (0x00000001 << (type));
			} else {
				SDL_eventstate &= ~(0x00000001 << (type));
			}
			while ( SDL_PollEvent(&bitbucket) > 0 )
				;
			break;
		
		default:
			break;
	}
	return(current_state);
}
