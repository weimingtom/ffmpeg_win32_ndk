//#include "SDL_config.h"

#ifndef _SDL_error_c_h
#define _SDL_error_c_h

#define ERR_MAX_STRLEN	128
#define ERR_MAX_ARGS	5

typedef struct SDL_error {
	int error;
	char key[ERR_MAX_STRLEN];
	int argc;
	union {
		void *value_ptr;
		int value_i;
		double value_f;
		char buf[ERR_MAX_STRLEN];
	} args[ERR_MAX_ARGS];
} SDL_error;

#endif
