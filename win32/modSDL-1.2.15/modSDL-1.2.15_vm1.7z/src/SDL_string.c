//#include "SDL_config.h"
#include "SDL_stdinc.h"

size_t SDL_strlcpy(char *dst, const char *src, size_t maxlen)
{
    size_t srclen = SDL_strlen(src);
    if ( maxlen > 0 ) {
        size_t len = SDL_min(srclen, maxlen-1);
        SDL_memcpy(dst, src, len);
        dst[len] = '\0';
    }
    return srclen;
}

size_t SDL_strlcat(char *dst, const char *src, size_t maxlen)
{
    size_t dstlen = SDL_strlen(dst);
    size_t srclen = SDL_strlen(src);
    if ( dstlen < maxlen ) {
        SDL_strlcpy(dst+dstlen, src, maxlen-dstlen);
    }
    return dstlen+srclen;
}
