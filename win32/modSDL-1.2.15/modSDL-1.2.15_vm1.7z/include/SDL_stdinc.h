#ifndef _SDL_stdinc_h
#define _SDL_stdinc_h

//#include "SDL_config.h"

#include <sys/types.h>
#include <stdio.h>
# include <stdlib.h>
# include <stddef.h>
# include <stdarg.h>
#  include <malloc.h>
# include <string.h>
# include <strings.h>
# include <inttypes.h>
# include <stdint.h>
# include <ctype.h>

typedef enum {
	SDL_FALSE = 0,
	SDL_TRUE  = 1
} SDL_bool;

typedef int8_t		Sint8;
typedef uint8_t		Uint8;
typedef int16_t		Sint16;
typedef uint16_t	Uint16;
typedef int32_t		Sint32;
typedef uint32_t	Uint32;

#ifdef SDL_HAS_64BIT_TYPE
typedef int64_t		Sint64;
#ifndef SYMBIAN32_GCCE
typedef uint64_t	Uint64;
#endif
#else

typedef struct {
	Uint32 hi;
	Uint32 lo;
} Uint64, Sint64;
#endif

#include "begin_code.h"
#ifdef __cplusplus
extern "C" {
#endif

#define SDL_arraysize(array)	(sizeof(array)/sizeof(array[0]))
#define SDL_malloc	malloc
#define SDL_free	free
#define SDL_realloc	realloc
#define SDL_memset      memset
//FIXME:
#define SDL_memcpy      memcpy

#define SDL_snprintf    snprintf
#define SDL_strlen      strlen
#define SDL_strcasecmp  strcasecmp

#define SDL_min(x, y)	(((x) < (y)) ? (x) : (y))
#define SDL_max(x, y)	(((x) > (y)) ? (x) : (y))

#ifdef __cplusplus
}
#endif
#include "close_code.h"

#endif
