#ifndef _SDL_H
#define _SDL_H

#include "SDL_stdinc.h"
#include "SDL_audio.h"
#include "SDL_error.h"
#include "SDL_events.h"
#include "SDL_thread.h"
#include "SDL_timer.h"

#include "begin_code.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SDL_INIT_AUDIO		0x00000010
#define SDL_INIT_EVENTTHREAD	0x01000000
#define SDL_INIT_EVERYTHING	0x0000FFFF

extern DECLSPEC int SDLCALL SDL_Init(Uint32 flags);
extern DECLSPEC int SDLCALL SDL_InitSubSystem(Uint32 flags);
extern DECLSPEC void SDLCALL SDL_QuitSubSystem(Uint32 flags);
extern DECLSPEC Uint32 SDLCALL SDL_WasInit(Uint32 flags);
extern DECLSPEC void SDLCALL SDL_Quit(void);

#ifdef __cplusplus
}
#endif
#include "close_code.h"

#endif
