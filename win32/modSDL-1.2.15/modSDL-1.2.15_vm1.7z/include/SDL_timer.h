#ifndef _SDL_timer_h
#define _SDL_timer_h

#include "SDL_stdinc.h"

#include "begin_code.h"
#ifdef __cplusplus
extern "C" {
#endif

extern DECLSPEC void SDLCALL SDL_Delay(Uint32 ms);

#ifdef __cplusplus
}
#endif
#include "close_code.h"

#endif
