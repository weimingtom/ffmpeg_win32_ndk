#ifndef _SDL_events_h
#define _SDL_events_h

#include "SDL_stdinc.h"
#include "SDL_error.h"

#include "begin_code.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
       SDL_NOEVENT = 0,
       SDL_QUIT,
       SDL_USEREVENT = 24,
       SDL_NUMEVENTS = 32
} SDL_EventType;

#define SDL_EVENTMASK(X)	(1<<(X))
typedef enum {
	SDL_QUITMASK		= SDL_EVENTMASK(SDL_QUIT),
} SDL_EventMask ;

#define SDL_ALLEVENTS		0xFFFFFFFF

typedef struct SDL_UserEvent {
	Uint8 type;
	int code;
	void *data1;
	void *data2;
} SDL_UserEvent;

typedef union SDL_Event {
	Uint8 type;
	SDL_UserEvent user;
} SDL_Event;

extern DECLSPEC void SDLCALL SDL_PumpEvents(void);

typedef enum {
	SDL_ADDEVENT,
	SDL_PEEKEVENT,
	SDL_GETEVENT
} SDL_eventaction;

extern DECLSPEC int SDLCALL SDL_PeepEvents(SDL_Event *events, int numevents,
				SDL_eventaction action, Uint32 mask);
extern DECLSPEC int SDLCALL SDL_PollEvent(SDL_Event *event);
extern DECLSPEC int SDLCALL SDL_WaitEvent(SDL_Event *event);
extern DECLSPEC int SDLCALL SDL_PushEvent(SDL_Event *event);

typedef int (SDLCALL *SDL_EventFilter)(const SDL_Event *event);
extern DECLSPEC void SDLCALL SDL_SetEventFilter(SDL_EventFilter filter);
extern DECLSPEC SDL_EventFilter SDLCALL SDL_GetEventFilter(void);

#define SDL_QUERY	-1
#define SDL_IGNORE	 0
#define SDL_DISABLE	 0
#define SDL_ENABLE	 1
extern DECLSPEC Uint8 SDLCALL SDL_EventState(Uint8 type, int state);

#ifdef __cplusplus
}
#endif
#include "close_code.h"

#endif
